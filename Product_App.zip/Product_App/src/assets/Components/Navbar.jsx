import React from 'react'
import {Link} from 'react-router-dom'
import "../../App.css"
const Navbar = () => {
  return (
    <nav className="nav">
      <h2>Product Management</h2>
      <div>
        <Link to="/">Home</Link>
        <Link to="/add">Add Product</Link>
      </div>
    </nav>
  );  
}

export default Navbar