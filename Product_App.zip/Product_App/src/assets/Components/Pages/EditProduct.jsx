import React,{useEffect,useState} from 'react'
import {useNavigate,useParams} from 'react-router-dom'
import ProductService from '../Services/ProductService'
import "../../../App.css";

const EditProduct = () => {
    const {id}=useParams();
    const navigate=useNavigate();
    const [products,setProducts]=useState({
        name:"",
        price:"",
        rating:"",
        imgUrl:""
    });
    useEffect(()=>{
        ProductService.getProductById(id).then((res)=>{
            setProducts(res.data)});
        },[id])
    
    
        const updateProduct=(e)=>{
            e.preventDefault();
            ProductService.updateProducts(id,products).then(()=>navigate("/"));
        }
        const handleChange=(e)=>{
            setProducts({...products,[e.target.name]:e.target.value})
        }
    
  return (
    <div className='container'>

        <h2>EditProduct</h2>
        <form onSubmit={updateProduct}>
            <input type="text" name='name' value={products.name} onChange={handleChange} placeholder='Name'/>
            <input type="text" name="price"  value={products.price} onChange={handleChange}placeholder='Price' />
            <input type="text" name="rating" value={products.rating} onChange={handleChange}placeholder='Rating'/>
            <input type="text" name="imgUrl" value={products.imgUrl} onChange={handleChange}placeholder='ImgURL' />
            <button type='submit' className='btn btn-edit'>Update</button>
        </form>
    </div>
  )
}

export default EditProduct