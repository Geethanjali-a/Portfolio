import React from 'react'
import { useEffect,useState } from 'react'
import ProductService from '../Services/ProductService'
import {Link} from 'react-router-dom'
import "../../../App.css"

const ProductList = () => {
    let [products,setProducts]=useState([]);
    useEffect(()=>{
        loadProducts();
    },[])
    const loadProducts=()=>{
        ProductService.getProducts().then((res)=>{
            setProducts(res.data);
        })
    }
    const deleteProducts=(id)=>{
        ProductService.deleteProducts(id).then(()=>{
            loadProducts();
        })
    }
  return (
    <div className='container'>
     <h2>Product List</h2>
     <table border="1" width="100%" className='table'>
        <thead>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>PRICE</th>
                <th>RATING</th>
                <th>ImgURL</th>
            </tr>
        </thead>
        <tbody>
            {products.map((p)=>(
               <tr key={p.pid}>
                  <td>{p.pid}</td>
                  <td>{p.name}</td>
                  <td>{p.price}</td>
                  <td>{p.rating}</td>
                  <td>{p.imgUrl ?(
                    <img src={p.imgUrl} alt={p.name} className='product-img'/>):(<span>No Image</span>)}
                  </td>
                  <td>
                    <Link to={`/edit/${p.pid}`}>Edit</Link>
                    <button onClick={()=>{
                        deleteProducts(p.pid)}} className='btn btn-delete'>Delete</button>
                  </td>
               </tr>
            ))}
        </tbody>
     </table>
    </div>
  )
}

export default ProductList