import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom';
import ProductService from '../Services/ProductService';
import "../../../App.css"
const AddProduct = () => {
    const navigate=useNavigate();
    const[products,setProducts]=useState({
        name:"",
        price:"",
        rating:"",
        imgUrl:"",
    });
    const handleChange=(e)=>{
        setProducts({...products,[e.target.name]:e.target.value})
    }
    const saveProducts=(e)=>{
        e.preventDefault();
        ProductService.addProducts(products).then(()=>{navigate("/")})
        .catch((error)=>{
          console.log(error);
        })
    }
  return (
    <div className="container">
      <h2>AddProducts</h2>
      <form className="container" onSubmit={saveProducts}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          required
          onChange={handleChange}
        />
        <input
          type="text"
          name="price"
          placeholder="Price"
          required
          onChange={handleChange}
        />
        <input
          type="text"
          name="rating"
          placeholder="Rating"
          required
          onChange={handleChange}
        />
        <input
          type="text"
          name="imgUrl"
          placeholder="ImageURL"
          required
          onChange={handleChange}
        />
        <button type='submit' className='btn btn-add'>Save</button>
      </form>
    </div>
  );
}

export default AddProduct