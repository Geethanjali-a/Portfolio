import axios from "axios";
const API_URL = "http://localhost:8080/api/product";

class ProductService {
  async getProducts() {
    return axios.get(API_URL);
  }

//   addProducts = async (products) => {
//     try {
//       const res = await fetch(API_URL, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(products),
//       });
//     } catch (error) {
//       console.log(error);
//     }
//   };
//   getProducts = async () => {
//     try {
//       const result = await axios.get(API_URL);
//       return result.data;
//     } catch (error) {
//       console.log(error);
//     }
//   };
//   updateProduct = async (id, products) => {
//     try {
//       let res = await fetch(`${API_URL}/${id}`, {
//         method: "PUT",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(products),
//       });
//     } catch (error) {
//       console.log(error);
//     }
//   };
getProductById(id){
    return axios.get(`${API_URL}/${id}`);
}
addProducts(product){
    return axios.post(API_URL,product);
}
updateProducts(id,product){
    return axios.put(`${API_URL}/${id}`,product);
}
  deleteProducts(id) {
    return axios.delete(`${API_URL}/${id}`);
  }
}
export default new ProductService();
