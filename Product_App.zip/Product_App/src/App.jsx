import React from 'react'
import {BrowserRouter,Route,Routes} from 'react-router-dom';
import AddProduct from './assets/Components/Pages/AddProduct';
import ProductList from './assets/Components/Pages/ProductList';
import EditProduct from './assets/Components/Pages/EditProduct';
import Navbar from './assets/Components/Navbar';

const App = () => {
  return (
   <BrowserRouter>
   <Navbar></Navbar>
   <Routes>
    <Route path="/" element={<ProductList/>}></Route>
    <Route path="/add" element={<AddProduct/>}></Route>
    <Route path="/edit/:id" element={<EditProduct/>}></Route>
   </Routes>
   </BrowserRouter>
  )
}

export default App